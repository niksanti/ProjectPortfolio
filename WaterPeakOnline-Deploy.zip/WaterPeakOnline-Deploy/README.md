# WaterPeakOnline

### VISIT WATERPEAKONLINE [HERE](https://waterpeakonline.onrender.com/)

### RUNNING THE PROGRAM
1. To run the program, open the command prompt in the folder where the project is located "./CSSWENG-PROJECT"

2. On the command prompt, enter the following commands in the command prompt
> npm i
>
> node index.js
