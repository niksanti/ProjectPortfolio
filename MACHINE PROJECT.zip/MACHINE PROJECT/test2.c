#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int getSundayPrice ()
{
	int nNum;
	int nUp = 110;
	int nLow = 90;
	//randon number generator for Sunday price//
	nNum = (rand() % (nUp - nLow +1)) + nLow;
	
	return nNum;
}

void buyTurnips (int* nBells, int* nTurnips)
{
	
	int nInput1;
	int nInput2;
	int nSundayprice;
	
	nSundayprice = getSundayPrice ();
	printf ("Price for turnips today is %d bells.\n\n", nSundayprice);
	printf ("Do you want to buy? ");
	scanf ("%d", &nInput1);
	
	if(nInput1 == 1)
	{
		printf ("\nHow many turnips do you want to buy? (You can only buy in stacks of 10)\n");
		scanf ("%d", &nInput2);
		
		while (nInput2 % 10 != 0)
		{
			printf ("\nYou can only buy in stacks!\n");
			printf ("Please re-enter a valid number.\n\n");
			scanf ("%d", &nInput2);
		}
		
		*nTurnips = nInput2;
		*nBells = *nBells - (nInput2 * nSundayprice);
		printf ("You will checkout: %d\n", nInput2 * nSundayprice);
	}
	else if (nInput1 == 0)
	{
		printf ("\nDay ends.\n\n");
	}
	
}

int main ()
{
	int nBells = 5000;
	int nTurnips = 0;
	srand (time(NULL));
	buyTurnips (&nBells, &nTurnips);
	
	printf ("Bells: %d\n", nBells);
	printf ("Turnips: %d\n", nTurnips);
	
	return 0;
}


