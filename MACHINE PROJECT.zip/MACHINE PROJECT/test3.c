#include <stdio.h>

/*void askInput (int Input)
{
	printf ("Please enter a positive number: ");
	scanf ("%d", &Input);
}

void checkInput (int Input)
{
	if (Input < 0)
	{
		askInput (Input);
		checkInput (Input);
	}
}*/

int main ()
{
	int n;
	
	printf ("How many turnips in stacks do you want to buy?: ");
	scanf ("%d", &n);
	
	while (n % 10 != 0)
	{
		printf ("You can only buy in stacks!\n");
		printf ("Please enter a valid number\n");
		scanf ("%d", &n);
	}
	
	printf ("\nYou successfully bought stacks :)");
	
	return 0;
}
