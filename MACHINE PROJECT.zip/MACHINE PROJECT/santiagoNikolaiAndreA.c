/************************************************************************************************************************* 
This is to certify that this project is my own work, based on my personal efforts in 
studying and applying the concepts learned.  I have constructed the functions and their 
respective algorithms and corresponding code by myself.  The program was run, tested, and 
debugged by my own efforts.  I further certify that I have not copied in part or whole or 
otherwise plagiarized the work of other students and/or persons.
 
<SANTIAGO, Nikolai Andre A. >, DLSU ID# <12035270> 
*************************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//function to generate the Sunday buy price of turnips//
int getSundayPrice ()
{
	int nNum;
	int nUp = 110;
	int nLow = 90;
	
	nNum = (rand() % (nUp - nLow +1)) + nLow;
	
	return nNum;
}

//function to randomize the weekly price trend//
int getWeeklyTrend ()
{
	int n2;
	int nUp = 3;
	int nLow = 1;
	
	n2 = (rand() % (nUp - nLow +1)) + nLow;
	
	return n2;
}

//function to generate the weekly selling price of turnips//
int getWeeklyPrice ()
{
	int nNum1;
	int nUp1;
	int nLow1 = 80;
	int nNum2;
	int nUp2;
	int nLow2;
	int nNum3;
	int nUp3;
	int nLow3 = 20;
	int nSundayprice;
	
	nSundayprice = getSundayPrice ();
	nUp1 = nSundayprice * 1.05;
	nUp2 = nSundayprice * 3;
	nLow2 = nSundayprice;
	nUp3 = nSundayprice;
	
	switch (getWeeklyTrend ())
	{
		//Average trend//
		case 1: 
			nNum1 = (rand() % (nUp1 - nLow1 +1)) + nLow1;
			return nNum1;
			break;
		//Awesome trend//
		case 2:
			nNum2 = (rand() % (nUp2 - nLow2 +1)) + nLow2;
			return nNum2;
			break;
		//Bad trend//
		case 3: 
			nNum3 = (rand() % (nUp3 - nLow3 +1)) + nLow3;
			return nNum3;
			break;
	}
	return 1;
}

//this function allows the user to buy turnips during Sundays (Day 1)//
void buyTurnips (int* pB1, int* pT1)
{
	
	int nInput1;
	int nInput2;
	int nSundayprice;
	
	nSundayprice = getSundayPrice ();
	printf ("========================================================================================================================");
	printf ("\nToday is SUNDAY, and Daisy Mae has visited to sell you turnips:\n");
	printf ("\n%d bells per 1 stack of turnips\n\n", nSundayprice);
	printf ("Do you want to buy? (Enter 1 if YES or enter 0 if NO) ");
	scanf ("%d", &nInput1);
	//while loop that validates input from the user and prompts for a valid input//
	while (nInput1 > 1 || nInput1 < 0)
	{
		printf ("Invalid input. Please try again: ");
		scanf ("%d", &nInput1);
	}
	
	if(nInput1 == 1)
	{
		printf ("How many turnips do you want to buy? (You can only buy in stacks of 10) ");
		scanf ("%d", &nInput2);
		//while loop that checks if user has inputed stacks of 10//
		while (nInput2 % 10 != 0)
		{
			printf ("You can only buy in stacks!\n");
			printf ("Please re-enter a valid number: ");
			scanf ("%d", &nInput2);
		}
		//while loop to prevent user from having a negative value of bells//
		while (*pB1 < nInput2 * nSundayprice)
		{
			printf ("You do not have enough bells to purchase that many stacks.\n");
			printf ("Please re-enter a value: ");
			scanf ("%d", &nInput2);
		}
		*pT1 += nInput2;
		*pB1 = *pB1 - (nInput2 * nSundayprice);
		printf ("You will checkout: %d bells\n", nInput2 * nSundayprice);
	}
	//ends the day if user does not want to buy turnips//
	else if (nInput1 == 0)
	{
		printf ("\nDay ends.\n\n");
	}	
}

//this function allows the user to sell his/her turnips on Nook's Cranny store//
void sellTurnips (int* pB2, int* pT2)
{
	int nInput1;
	int nInput2;
	int nWeeklyprice;
	
	nWeeklyprice = getWeeklyPrice ();
	printf ("========================================================================================================================\n");
	printf ("Welcome to Nook's Cranny\n\n");
	printf ("Today we are buying stacks of turnips for %d bells!\n\n", nWeeklyprice);
	printf ("Do you want to sell your turnips? (Enter 1 if YES or enter 0 if NO) ");
	scanf ("%d", &nInput1);
	//while loop that validates input from the user and prompts for a valid input//
	while (nInput1 > 1 || nInput1 < 0)
	{
		printf ("Invalid input. Please try again: ");
		scanf ("%d", &nInput1);
	}
	
	if (nInput1 == 1)
	{
		printf ("How many do you want to sell? (You can only sell in stacks of 10) ");
		scanf ("%d", &nInput2);
		//while loop that checks if user has inputed stacks of 10//
		while (nInput2 % 10 != 0)
		{
			printf ("\nYou can only sell in stacks!\n");
			printf ("Please re-enter a valid number: ");
			scanf ("%d", &nInput2);
		}
		//while loop to prevent user from having a negative value of turnips//
		while (*pT2 < nInput2)
		{
			printf ("You do not have enough turnips to sell.\n");
			printf ("Please re-enter a value: ");
			scanf ("%d", &nInput2);
		}
		*pT2 -= nInput2;
		*pB2 = *pB2 + (nInput2 * nWeeklyprice);
		printf ("\nYou will recieve: %d\n", nInput2 * nWeeklyprice);
	}
	//ends the day if user does not want to sell turnips//
	else if (nInput1 == 0)
	{
		printf ("\nDay ends.\n\n");
	}
}

int main ()
{
	int nBells = 5000;
	int nTurnips = 0;
	int nWeek = 1;
	int nDay;
	// seed random number generator//
	srand (time(NULL));
	printf ("************************************************************************************************************************\n");
	printf ("Hey there Mayor! Welcome to the city.\n");
	printf ("\nREADY TO START EARNING A FORTUNE?\n");
	printf ("As the mayor, you're tasked to raise your city's bells to 1,000,000,000 within 20 weeks.\n");
	printf ("\nHere's 5,000 bells to kickstart your journey, good Luck!!\n");
	printf ("************************************************************************************************************************\n");
	//while loop for the week cycle//
	while (nWeek <= 20)
	{
		//conditional statement to reset days within the week//
		if (nDay != 8)
		{
			printf ("========================================================================================================================\n");
			printf ("\n\t\t\t\t\t\t\tWeek %d\n", nWeek);
			//for loop for the day cycle//
			for (nDay = 1; nDay <= 7; nDay++)
			{	
				
				printf ("\t\t\t\t\t\t\tDay %d\n", nDay);
				if (nDay == 1)
				{	//condition to check if player is still able to purchase turnips when the week resets, if he/she is unable to buy, the game ends//
					if (nBells < getSundayPrice () * 10)
     				{
						printf ("GAME OVER. You are unable to purchase any turnips because you ran out of bells!\n");
						printf ("Please try again!");
						return 0;
					}
					else
					{
						//calls the buy function since its Sunday (Day 1)//
						buyTurnips (&nBells, &nTurnips);
						printf ("||Bells: %d\n", nBells);
						printf ("||Turnips: %d\n", nTurnips);
						printf ("========================================================================================================================\n");
					}
				}
				else if (nDay >= 2 && nDay <=7)
				{
						//calls the sell function to prompt the user to sell turnips within days 2-7//
						sellTurnips (&nBells, &nTurnips);
						printf ("||Bells: %d\n", nBells);
						printf ("||Turnips: %d\n", nTurnips);
						printf ("========================================================================================================================\n");	
						//condition to skip the week if player has ran out of turnips for that week//
						if (nTurnips == 0)
						{
							printf ("The week fast forwards because you don't have any turnips to sell.\n");
							nDay = 7 + 1;
							nWeek++;
						}
				}
			} 
		} 
		else
		{
			//any remaining turnips within the week will go bad, since a turnip has a lifespan of 7 days in this program//
			if (nTurnips > 0 )
			{
				printf ("Oh no! All your remaining turnips went bad.\n");
				nTurnips = 0;
		 }
			nDay = 1;
			nWeek++;
		}
	}
	//summates the total number of bells the player has acquired during the entire run of the program, then decides if the player has won or lost the game//
	printf ("\nAfter 20 weeks, you have accumulated a total of: %d bells\n\n.", nBells);
	if (nBells > 1000000000)
	{
		printf ("CONGRATULATIONS\n");
		printf ("You have successfully reached the end goal");
	}
	else if (nBells < 1000000000)
	{
		printf ("You have failed to reach 1,000,000,000 bells\n");
		printf ("Please try again!");
	}
	
	return 0;
}
