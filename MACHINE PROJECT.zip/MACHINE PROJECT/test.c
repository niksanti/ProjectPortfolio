#include <stdio.h>
#include <stdlib.h>

int main ()
{
	int nWeek = 1, nDay;
	int nInput;
	/*for (nWeek = 1; nWeek <= 7; nWeek++)
	{
		printf ("Week %d\n", nWeek);
		for (nDay = 1; nDay <= 7; nDay++)
		{
			printf ("Day %d\n", nDay);
			printf ("Do you want to buy today? [Y/N] \n");
			scanf ("%c", &cInput);
			
			if (cInput == 'Y')
			{
				printf ("SAMPLE 1\n");
			}
			else if (cInput == 'N')
			{
				printf ("sample 2\n");
			} 
			
		}
	}*/
	
	while (nWeek <= 20)
	{
		
		if (nDay != 8)
		{
			printf ("Week %d\n", nWeek);
			for (nDay = 1; nDay <= 7; nDay++)
		{	
			printf ("Day %d\n", nDay);
			printf ("Do you want to buy turnips today? [1/0] \n");
			scanf ("%d", &nInput);
			
			if (nInput == 1)
			{
				printf ("SAMPLE 1\n");
			}
			else if (nInput == 0)
			{
				printf ("sample 2\n");
			}
		} 
		} 
		else
		{
			nDay = 1;
			nWeek++;
		}
	}
	return 0;
} 
